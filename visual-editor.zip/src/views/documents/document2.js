const hbs = `

  
  <div class="sortable">
    {{{content}}}
  </div>
`;

const document = {
  hbs,
  name: "Basic document",
};

export default document;
